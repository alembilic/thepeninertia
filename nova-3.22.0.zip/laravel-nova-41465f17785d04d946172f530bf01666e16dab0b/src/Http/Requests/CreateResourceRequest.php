<?php

namespace Laravel\Nova\Http\Requests;

class CreateResourceRequest extends NovaRequest
{
    //
}
